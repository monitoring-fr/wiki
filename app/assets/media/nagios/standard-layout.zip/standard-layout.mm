<map version="0.8.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1249978787250" ID="Freemind_Link_783495089" MODIFIED="1250162903875" TEXT="/usr/local/nagios/">
<font BOLD="true" NAME="SansSerif" SIZE="20"/>
<icon BUILTIN="gohome"/>
<hook NAME="accessories/plugins/HierarchicalIcons.properties"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1249978810031" ID="_" MODIFIED="1249981109593" POSITION="right" TEXT="bin/">
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1249979025359" ID="Freemind_Link_313194352" MODIFIED="1250163911140" TEXT="nagios">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1249979031375" ID="Freemind_Link_235601705" MODIFIED="1250163917359" TEXT="nagiostats">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1249979035828" ID="Freemind_Link_1233905155" MODIFIED="1250163926078" TEXT="p1.pl">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1249978818625" ID="Freemind_Link_1805217156" MODIFIED="1249981109609" POSITION="left" TEXT="sbin/">
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1249979082843" ID="Freemind_Link_395480380" MODIFIED="1249981109609" TEXT="avail.cgi">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1249979090437" ID="Freemind_Link_760788337" MODIFIED="1249981109609" TEXT="tac.cgi">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250162867968" ID="Freemind_Link_138201754" MODIFIED="1250163665515" TEXT="cmd.cgi">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250162883593" ID="Freemind_Link_984417409" MODIFIED="1250163665515" TEXT="config.cgi">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250162891562" ID="Freemind_Link_234409981" MODIFIED="1250163665515" TEXT="extinfo.cgi">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250162896921" ID="Freemind_Link_132910128" MODIFIED="1250163665515" TEXT="histogram.cgi">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163599375" ID="Freemind_Link_1247106944" MODIFIED="1250163665500" TEXT="history.cgi">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163609421" ID="Freemind_Link_106187790" MODIFIED="1250163665500" TEXT="notifications.cgi">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163618390" ID="Freemind_Link_768389155" MODIFIED="1250163665500" TEXT="outages.cgi">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163625656" ID="Freemind_Link_1186708784" MODIFIED="1250163665500" TEXT="showlog.gci">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163633500" ID="Freemind_Link_608230683" MODIFIED="1250163665500" TEXT="status.cgi">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163647656" ID="Freemind_Link_1156224329" MODIFIED="1250163665500" TEXT="summary.cgi">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163656593" ID="Freemind_Link_839076035" MODIFIED="1250163665500" TEXT="trends.cgi">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1249978825921" ID="Freemind_Link_727928411" MODIFIED="1249981109609" POSITION="right" TEXT="var/">
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1249978856718" ID="Freemind_Link_1342406858" MODIFIED="1249981109640" TEXT="archives/">
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1249979537921" ID="Freemind_Link_1031520650" MODIFIED="1249981109640" TEXT="nagios-2009-1214.log">
<font ITALIC="true" NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1249979548109" ID="Freemind_Link_1174522024" MODIFIED="1249981109640" TEXT="nagios-2009-1215.log">
<font ITALIC="true" NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1249979367562" ID="Freemind_Link_1933200384" MODIFIED="1249981109656" TEXT="rw/">
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1249979374343" ID="Freemind_Link_975088570" MODIFIED="1249981109656" TEXT="nagios.cmd">
<font ITALIC="true" NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1249979417109" ID="Freemind_Link_4893648" MODIFIED="1249981109656" TEXT="spool/">
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1249979435375" ID="Freemind_Link_310149496" MODIFIED="1249981109671" TEXT="checkresults/">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1249979443312" ID="Freemind_Link_1440126632" MODIFIED="1249981109671" TEXT="cF0JjVP.ok">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1249979467531" ID="Freemind_Link_499031906" MODIFIED="1249981109671" TEXT="cF0JjVP">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1249979284078" ID="Freemind_Link_910697668" MODIFIED="1250163832796" TEXT="nagios.lock">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163858234" ID="Freemind_Link_1904357422" MODIFIED="1250163973312" TEXT="objects.cache">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163943093" ID="Freemind_Link_98484522" MODIFIED="1250163973312" TEXT="nagios.log">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163950765" ID="Freemind_Link_324561198" MODIFIED="1250163973312" TEXT="retention.dat">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163966078" ID="Freemind_Link_1633926486" MODIFIED="1250163973312" TEXT="status.dat">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1249978832750" ID="Freemind_Link_956700721" MODIFIED="1249981109671" POSITION="left" TEXT="etc/">
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1249979139859" ID="Freemind_Link_1968358004" MODIFIED="1250162694562" TEXT="ressource.cfg">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1249979147375" ID="Freemind_Link_79888567" MODIFIED="1250162843312" TEXT="nagios.cfg">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1249979152156" ID="Freemind_Link_695393900" MODIFIED="1250162694578" TEXT="cgi.cfg">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250162525484" ID="Freemind_Link_1249931942" MODIFIED="1250162706812" TEXT="objects/">
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1250162531203" ID="Freemind_Link_1051022376" MODIFIED="1250162706812" TEXT="">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1250162577218" ID="Freemind_Link_256103590" MODIFIED="1250162807375" TEXT="windows.cfg">
<font ITALIC="true" NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1250162590843" ID="Freemind_Link_754651137" MODIFIED="1250162807375" TEXT="localhost.cfg">
<font ITALIC="true" NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1250162608234" ID="Freemind_Link_240160987" MODIFIED="1250162807375" TEXT="commands.cfg">
<font ITALIC="true" NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1250162620875" ID="Freemind_Link_599131779" MODIFIED="1250162807375" TEXT="printer.cfg">
<font ITALIC="true" NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1250162629281" ID="Freemind_Link_135805130" MODIFIED="1250162807375" TEXT="switch.cfg">
<font ITALIC="true" NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1250162763484" ID="Freemind_Link_988410071" MODIFIED="1250162807375" TEXT="templates.cfg">
<font ITALIC="true" NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1250162769015" ID="Freemind_Link_1858496953" MODIFIED="1250162807375" TEXT="timeperiods.cfg">
<font ITALIC="true" NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1250162795468" ID="Freemind_Link_721039184" MODIFIED="1250162807375" TEXT="contacts.cfg">
<font ITALIC="true" NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1249979675343" ID="Freemind_Link_1758320247" MODIFIED="1249981109750" POSITION="right" TEXT="libexec/">
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1249979680953" ID="Freemind_Link_674270871" MODIFIED="1249981109750" TEXT="check_nrpe">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1249979688078" ID="Freemind_Link_796212505" MODIFIED="1249981109765" TEXT="check_http">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250162557953" ID="Freemind_Link_601575182" MODIFIED="1250163987562" TEXT="check_...">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1250162733359" ID="Freemind_Link_773638676" MODIFIED="1250162736515" POSITION="left" TEXT="share/">
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1250163680250" ID="Freemind_Link_1981154217" MODIFIED="1250164002046" TEXT="config.inc.php">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163718156" ID="Freemind_Link_751581739" MODIFIED="1250163725890" TEXT="docs/">
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163730500" ID="Freemind_Link_651321058" MODIFIED="1250163732625" TEXT="images/">
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163734781" ID="Freemind_Link_835729734" MODIFIED="1250163738328" TEXT="contexthelp/">
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163744203" ID="Freemind_Link_1777279461" MODIFIED="1250163746656" TEXT="includes/">
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163751906" ID="Freemind_Link_1107160044" MODIFIED="1250163998484" TEXT="index.php">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163758718" ID="Freemind_Link_1013792878" MODIFIED="1250163998484" TEXT="main.php">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163765515" ID="Freemind_Link_534375207" MODIFIED="1250163772796" TEXT="media/">
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163775281" ID="Freemind_Link_1121125813" MODIFIED="1250163994406" TEXT="robots.txt">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163787921" ID="Freemind_Link_1722304159" MODIFIED="1250163994406" TEXT="side.php">
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163794406" ID="Freemind_Link_67369664" MODIFIED="1250163811515" TEXT="ssi/">
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1250163803234" ID="Freemind_Link_730416870" MODIFIED="1250163806750" TEXT="stylesheets/">
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
</node>
</map>
